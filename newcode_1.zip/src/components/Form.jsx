import React, { useState, useEffect} from "react";
import instance from "../api";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const Form = () => {
  const [formData, setFormData] = useState({
    block: "",
    applicationId: "",
    gender: "",
  });


  const [blockOptions, setBlockOptions] = useState([]);
  const [genderOptions, setGenderOptions] = useState([]);

  useEffect(() => {
    instance
      .get("/get-blocks")
      .then((response) => {
        // console.log(response);
        setBlockOptions(response.data || []);
      })
      .catch((error) => {
        console.error("Error fetching block options:", error);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // -------------------------------
  // const handleSubmit = async (e) => {
  //   e.preventDefault();

  //   const req = {
  //     block_id: formData.block,
  //     application_id: formData.applicationId,
  //     gender_id: formData.gender,
  //   };

  //   try {
  //     const response = await instance.post("/download-admit", req);

  //     if (response.data) {
  //       const pdfContent = response.data;
  //       // console.log(pdfContent)

  //       // Convert the HTML content to PDF
  //       const pdf = await html2pdf().from(pdfContent).outputPdf();

  //       // Create a Blob from the PDF content
  //       const blob = new Blob([pdf], { type: 'application/pdf' });
  //       console.log(blob)

  //       // Create a download link and trigger the download
  //       const link = document.createElement('a');
  //       link.href = URL.createObjectURL(blob);
  //       link.download = 'admitCard.pdf';
  //       link.click();
  //     } else {
  //       console.error('Server response does not contain valid PDF content.');
  //     }
  //   } catch (error) {
  //     console.error("Error fetching block options:", error);
  //   }
  // };
  // ----------------------------testing--------------------
  const handleSubmit = async (e) => {
    e.preventDefault();

    const staticHTMLContent = `<!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <link href="https://fonts.googleapis.com/css2?family=Tiro+Devanagari+Hindi&display=swap" rel="stylesheet">
          <!-- Other head elements -->
        </head>
        <body>
         <h1 style="color:red;">Hello World</h1>
        </body>
      </html>
    `;


    const req = {
      block_id: formData.block,
      application_id: formData.applicationId,
      gender_id: formData.gender,
    };

    try {
      const response = await instance.post("/download-admit", req);
      // console.log(response.data)
      const result = { data: staticHTMLContent };
      if (response.data) {
        // const pdfContent = response.data;
        const pdfContent = result.data;
        // Create a new jsPDF instance
        const pdf = new jsPDF();

        // Add HTML content to the PDF
        pdf.html(pdfContent, {
          callback: function (pdf) {
            pdf.save('admitCard.pdf');
          },
        });
        
      } else {
        console.error("Server response does not contain valid PDF content.");
      }
    } catch (error) {
      console.error("Error fetching block options:", error);
    }
  };

  

  return (
    <div className="bg-white shadow-lg py-8 px-16 max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-4 text-center">
        Download your Admit Card
      </h2>
      <form onSubmit={handleSubmit}>
        {/* Your form fields */}
        <div className="mb-4">
          <label htmlFor="block" className="block mb-1">
            Block
          </label>
          <select
            id="block"
            name="block"
            value={formData.block}
            onChange={handleChange}
            className="w-full p-2 border rounded-md focus:outline-none focus:border-blue-500"
            required
          >
            <option value="">Select Block</option>
            {blockOptions.length > 0 &&
              blockOptions.map((block) => (
                <option key={block.id} value={block.id}>
                  {block.block}
                </option>
              ))}
          </select>
        </div>
        <div className="mb-4">
          <label htmlFor="applicationId" className="block mb-1">
            Application ID
          </label>
          <input
            type="text"
            id="applicationId"
            name="applicationId"
            value={formData.applicationId}
            onChange={handleChange}
            className="w-full p-2 border rounded-md focus:outline-none focus:border-blue-500"
            placeholder="Enter Application ID"
            required
          />
        </div>
        <div className="mb-4">
          <label htmlFor="gender" className="block mb-1">
            Gender
          </label>
          <select
            id="gender"
            name="gender"
            onChange={handleChange}
            value={formData.gender}
            className="w-full p-2 border rounded-md focus:outline-none focus:border-blue-500"
            required
          >
            <option value="">Select Gender</option>
            <option value="1">Male</option>
            <option value="2">Female</option>
          </select>
          {/* ---------------------------------------------- */}
        </div>
        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition duration-300"
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default Form;
